class Coffee extends Beverages {

    @Override
    public void brew() {
        System.out.println("Dripping coffee through Filter");
    }

    @Override
    public void addCondiments() {
        System.out.println("Adding sugar and Milk");
    }

    @Override
    public void addExtras() {
        System.out.println("Adding vanilla Syrup");
    }
}

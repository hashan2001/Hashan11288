public class KitchenRoomLight implements Light {
    private int brightness = 0;

    @Override
    public void on() {
        brightness=100; 
        System.out.println("Kitchen Room is ON at full brightness");
    }

    @Override
    public void off() {
        brightness=0;
        System.out.println("KitchenRoom is OFF");
    }

    @Override
    public void dim(int level) {
        this.brightness = level;
        System.out.println("KitchenRoom is Dimmed to " + level + " %");
    }

    @Override
    public void getCurrentBrightness() {
        
    }

    public int getBrightness(){
        return brightness;
}
}

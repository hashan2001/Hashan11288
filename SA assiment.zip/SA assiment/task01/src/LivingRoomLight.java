public class LivingRoomLight implements Light {
    private int brightness ;

    @Override
    public void on() {
        brightness=100;
        System.out.println("LivingRoom is ON AT FULL BRIGHTNESS");
    }

    @Override
    public void off() {
        brightness=0;
        System.out.println("LivingRoom is OFF");
    }

    @Override
    public void dim(int level) {
        this.brightness = level;
        System.out.println("LivingRoom is Dim" + level + " %");
    }

    @Override
    public void getCurrentBrightness() {

    }

    public int getBrightness(){
        return brightness;
    }
}
